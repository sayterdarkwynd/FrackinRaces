function update(dt)
    effect.expire()
end
