
function init()
  effect.addStatModifierGroup({

  })
end